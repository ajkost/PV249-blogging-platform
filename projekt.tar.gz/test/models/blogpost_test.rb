require 'test_helper'

class BlogpostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
