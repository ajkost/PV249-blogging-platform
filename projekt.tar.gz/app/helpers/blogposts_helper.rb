module BlogpostsHelper
	include ActsAsTaggableOn::TagsHelper
end
